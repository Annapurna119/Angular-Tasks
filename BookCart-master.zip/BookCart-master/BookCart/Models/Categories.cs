﻿using System;
using System.Collections.Generic;

namespace BookCart.Models
{
    public partial class Categories
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
